# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['pyLMP', 'pyLMP.analysis', 'pyLMP.tools']

package_data = \
{'': ['*']}

install_requires = \
['Pubchempy>=1.0.4,<2.0.0',
 'alchemlyb>=2.2.0,<3.0.0',
 'jinja2>=3.1.3,<4.0.0',
 'moleculegraph @ git+https://github.com/maxfleck/moleculegraph.git@master',
 'numpy>=1.26.3,<2.0.0',
 'pandas>=2.1.4,<3.0.0',
 'pyyaml>=6.0.1,<7.0.0',
 'rdkit>=2023.9.6,<2024.0.0',
 'scipy>=1.13.0,<2.0.0',
 'seaborn>=0.13.2,<0.14.0',
 'toml>=0.10.2,<0.11.0']

setup_kwargs = {
    'name': 'pylmp',
    'version': '0.0.1',
    'description': '',
    'long_description': '<h1 align="center">\n  pyLMP\n</h1>\n<p align="center">This repository enables users to perform molecular dynamics simulations utilizing LAMMPS. It can either start from given parameter and data file, or create them itself by using moleculegraph, PLAYMOL and supplementary Python code. YAML files are utilized to parse simulation settings, such as ensemble definitions, sampling properties and system specific input.  </p>\n\nOnline documentation is available at: https://samirdarouich.github.io/pyLMP\n\n## 🚀 Getting Started\n\nGet started by running the following command to install:\n\n1. pyLMP\n```\ngit clone https://github.com/samirdarouich/pyLMP.git\ncd pyLMP\npip install -I .\n```\n2. PLAYMOL\n```\ngit clone https://github.com/atoms-ufrj/playmol\ncd playmol\nmake\n```\n\n\n## 🐍 Example program\n\n# pyLMP\n\nThis module enables users to perform molecular dynamics simulations utilizing LAMMPS with any force field provided as toml/json file. \nThere is the possiblity to provide data and LAMMPS compatible parameter files, or to build a system and write all necessary input using pyLMP, PLAYMOL, and moleculegraph.\n\n1) Read in the YAML files to define the system and simulation/sampling settings.\n\n```python\nlammps_setup = LAMMPS_setup( system_setup = "input/setup.yaml", \n                             simulation_default = "input/defaults.yaml",\n                             simulation_ensemble = "input/ensemble.yaml",\n                             simulation_sampling = "input/sampling.yaml",\n                             submission_command = "qsub"\n                            )\n```\n\n## Setting up a simulation pipeline\n\nIn this section the possibility to setup a simulation folder, along with a simulation pipeline using several ensembles, is provided.\n\n1) Setup simulation and build initial system (if not provided)\n\n```python\n# Define the simulation folder\nsimulation_folder = "md_thermo"\n\n# Define the ensembles that should be simulated (definition what each ensemble means is provided in yaml file)\nensembles = [ "em", "npt" ] \n\n# Define the simulation time per ensemble in nano seconds (for em the number of iterations is provided in the ensemble yaml)\nsimulation_times = [ 0, 10.0 ]\n\n# Define initial systems, in case the simulation should be continued from a prior simulation.\n# In that case, provide one initial structure for each temperature & pressure state.\n# If the simulation should start from an initial configuration, provide an empty list.\ninitial_systems = [ "/home/st/st_st/st_ac137577/workspace/software/pyLMP/example/butane_hexane/md_thermo/temp_343_pres_4/build/system.data" ]\n\n# Define if there is already a force field file\nff_file = ""\n\n# Provide kwargs that should be passed into the input template directly\ninput_kwargs = {  }\n\n# Define number of copies\ncopies = 2\n\n# Define if the inital system should build locally or with the cluster\non_cluster = False\n\n# Define the starting number for the first ensemble ( 0{off_set}_ensemble )\noff_set    = 0\n\nlammps_setup.prepare_simulation( folder_name = simulation_folder, ensembles = ensembles, simulation_times = simulation_times,\n                                 initial_systems = initial_systems, input_kwargs = input_kwargs, copies = copies,\n                                 ff_file = ff_file, on_cluster = on_cluster,  off_set = off_set )\n```\n\n2) Submit jobs to cluster\n\n```python\n# Submit the simulations\nlammps_setup.submit_simulation()\n```\n## Extract sampled properties\n\n```python\n# Extract properties from LAMMPS and analyse them\n\n# Define analysis folder\nanalysis_folder = "md_thermo"\n\n# Define analysis ensemble\nensemble = "01_npt"  \n\n# Properties to extract\nproperties = ["temperature", "potential energy", "kinetic energy", "enthalpy"]\n\n# Suffix of output file\noutput_suffix = "energy"\n\n# Percentage to discard from beginning of the simulation\nfraction = 0.25\n\nlammps_setup.analysis_extract_properties( analysis_folder = analysis_folder, ensemble = ensemble, extracted_properties = properties, \n                                          output_suffix = output_suffix, fraction =  fraction )\n```\n\n\n## 👫 Authors\n\nSamir Darouich - University of Stuttgart\n\n## 📄 License\n\nThis project is licensed under the MIT License - see the LICENSE.md file for details\n',
    'author': 'Samir Darouich',
    'author_email': 'samir.darouich@itt.uni-stuttgart.de',
    'maintainer': None,
    'maintainer_email': None,
    'url': 'https://github.com/samirdarouich/pyLMP.git',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
